package com.v6;
class NoAcTypeFoundException extends Exception
{
   String acType;
	NoAcTypeFoundException(String acType)
	{
		this.acType=acType;
	}
	
	public String getMessage()
	{
		return acType;
		
	}
}
