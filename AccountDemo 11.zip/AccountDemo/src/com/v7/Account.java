package com.v7;

class Account
{
	int number;

	String acType;

	double  balance;

	int noOfAccountHolders;

	public Account(int number, String acType, double balance,
			int noOfAccountHolders) {
		
		this.number = number;
		this.acType = acType;
		this.balance = balance;
		this.noOfAccountHolders = noOfAccountHolders;
	}
}
