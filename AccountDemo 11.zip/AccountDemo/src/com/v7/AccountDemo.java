package com.v7;

public class AccountDemo 
{
   public static void main(String args[])
   {
	   Account ack[]=new Account[5];
	   
	   ack[0]=new Account(1,"saving",3100.4,30);
	   ack[1]=new Account(2,"saving",1800.4,4);
	   ack[2]=new Account(3,"current",1050.4,5);
	   ack[3]=new Account(4,"current",100.4,3);
	   ack[4]=new Account(5,"saving",100.4,31);
	   
	   try{ 
	  Account obj3[]= searchAccountByBalance(ack,100.4);
	       for(Account ac:obj3)
	    	   if(ac!=null)
	    	   System.out.println(ac);
	  
	  
	  
	   }
	   catch(NoBalanceFoundException e)
	   {System.out.println(e.getMessage());}
	   
	 }
   
   
  static Account[] searchAccountByBalance(Account obj[],double j) throws NoBalanceFoundException
   {
	   if(obj==null)
		   return null;
	   
	   
	   int count=0;
	   Account obj2[]=new Account[5];
	   
	   for(Account ac:obj)
	   {
		   if(ac!=null)
		   if(j==ac.balance)
			   obj2[count++]=ac;
		   
	   }
	   if(count==0)
		   throw new NoBalanceFoundException(j);
	   
	   
	   return obj2;
   }
	
	
	
}
