package com.v7;
public class NoBalanceFoundException extends Exception
{

	     double balance;
	     NoBalanceFoundException(double balance)
		{
			this.balance=balance;
		}
		
		public String getMessage()
		{
			return Double.toString(balance);
			
		}
	}


